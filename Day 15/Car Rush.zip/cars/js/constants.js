class Constants
{
    constructor()
    {
        this.SET_SCORE="setScore";
        this.SCORE_UPDATED="scoreUpdated";
        this.UP_POINTS="upPoints";
    }
}