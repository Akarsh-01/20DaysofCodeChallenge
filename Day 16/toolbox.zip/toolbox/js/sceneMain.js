class SceneMain extends Phaser.Scene {
    constructor() {
        super('SceneMain');
    }
    preload()
    {
        //load our images or sounds
    	
    }
    create() {
        //defining our objects
        var gridConfig={rows:5,cols:5,scene:this};
        var alignGrid=new AlignGrid(gridConfig);
        alignGrid.show();
    }
    update() {
        //constant running loop 
    }
}